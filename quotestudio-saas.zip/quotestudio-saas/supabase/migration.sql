-- ═══════════════════════════════════════════════════════════════════════════
-- QUOTESTUDIO SAAS — Supabase Migration
-- Multi-tenant schema met Row Level Security
-- ═══════════════════════════════════════════════════════════════════════════

-- ── 1. TENANTS ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tenants (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL,                              -- "Electroworks BV"
  slug        text UNIQUE NOT NULL,                       -- "electroworks"
  plan        text NOT NULL DEFAULT 'free',               -- free | pro | business | enterprise
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- ── 2. TENANT SETTINGS (branding, voorwaarden, alles configureerbaar) ───────
CREATE TABLE IF NOT EXISTS tenant_settings (
  tenant_id           uuid PRIMARY KEY REFERENCES tenants(id) ON DELETE CASCADE,

  -- Identiteit
  company_name        text DEFAULT 'Mijn Bedrijf',
  company_name_short  text,                               -- korte naam voor UI
  app_name            text DEFAULT 'QuoteStudio',

  -- Branding
  logo_url            text,                                -- URL naar logo in Supabase Storage
  primary_color       text DEFAULT '#2563eb',              -- neutraal blauw als default
  accent_color        text,                                -- donkerder variant (auto-berekend als null)
  light_color         text,                                -- lichtere variant (auto-berekend als null)
  cover_image_url     text,                                -- standaard cover-foto
  favicon_url         text,

  -- Bedrijfsgegevens
  address             text,
  phone               text,
  fax                 text,
  email               text,
  website             text,
  vat_number          text,
  rsz_number          text,
  vat_label           text DEFAULT 'Ondernemingsnummer',
  rsz_label           text,

  -- Zone-terminologie (de kern van de white-label)
  zone_label          text DEFAULT 'Zone',                 -- "Vergaderzaal", "Verdieping", "Gebouw"
  zone_label_plural   text DEFAULT 'Zones',
  zone_tab_label      text DEFAULT 'Zones',
  -- Vertalingen
  zone_label_fr       text,
  zone_label_plural_fr text,
  zone_label_en       text,
  zone_label_plural_en text,

  -- Offerte-instellingen
  currency            text DEFAULT 'EUR',
  currency_symbol     text DEFAULT '€',
  default_vat_pct     numeric DEFAULT 21,
  default_language    text DEFAULT 'nl',
  default_cover_title text DEFAULT E'Gedetailleerde\nbudgetraming',

  -- Leasing / As-a-Service
  leasing_enabled     boolean DEFAULT false,
  leasing_label       text DEFAULT 'As-a-Service',
  leasing_label_full  text DEFAULT 'Product as a Service',

  -- Voorwaarden (arrays van tekst)
  conditions_intro    text DEFAULT 'Deze aanbieding is gebaseerd op de volgende voorwaarden en principes',
  conditions          text[],
  client_responsibilities text[],
  maintenance_text    text,
  maintenance_items   text[],
  proposal_items      text[] DEFAULT ARRAY['Projectmanagement', 'Levering', 'Installatie & testen'],

  -- Contactpagina
  contact_subtitle    text DEFAULT 'Uw aanspreekpunten bij {companyNameShort}',
  contact_photo_url   text,
  ccc_title           text,
  ccc_hours           text,

  -- Ondertekenpagina
  signing_legal_text  text,
  signing_legal_url   text,
  signing_checkbox    text,

  -- AI-prompts
  ai_role             text DEFAULT 'Je bent een offerte-specialist bij {companyNameShort}.',
  ai_sector           text,                                -- "AV", "security", "solar", etc.

  -- Login
  login_email_placeholder text DEFAULT 'naam@bedrijf.be',
  login_tagline       text DEFAULT 'Professionele offertes — sneller, slimmer en altijd correct opgemaakt.',

  -- Storage
  storage_prefix      text,                                -- auto: eerste 8 chars van tenant_id
  session_file_extension text DEFAULT '.quote',

  -- Timestamps
  updated_at          timestamptz NOT NULL DEFAULT now()
);

-- ── 3. USERS (uitbreiding van Supabase Auth) ────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id          uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  name        text,
  role        text NOT NULL DEFAULT 'user',                -- admin | user | viewer
  is_active   boolean DEFAULT true,
  last_active timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_users_email  ON users(email);

-- ── 4. QUOTES ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS quotes (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  owner_id        uuid REFERENCES users(id),
  
  -- Klantgegevens
  client_name     text,
  client_contact  text,
  client_email    text,
  client_address  text,
  client_vat      text,
  project_name    text,
  
  -- Status
  status          text NOT NULL DEFAULT 'draft',           -- draft | sent | signed | won | lost
  version         int NOT NULL DEFAULT 1,
  
  -- Offerte-inhoud (JSON blob voor nu, later normaliseren)
  session_data    jsonb,                                   -- volledige sessie-state
  
  -- Cover
  cover_title     text,
  cover_image_url text,
  
  -- Korting
  discount_pct    numeric DEFAULT 0,
  discount_label  text,
  
  -- Taal
  language        text DEFAULT 'nl',
  valid_until     date,
  
  -- Totalen (gedenormaliseerd voor dashboard)
  total_excl_vat  numeric,
  total_incl_vat  numeric,
  item_count      int DEFAULT 0,
  zone_count      int DEFAULT 0,
  
  -- Ondertekening
  signed_at       timestamptz,
  signature_data  text,
  signing_choice  text,                                    -- 'purchase' | 'lease_36' | 'lease_48' | 'lease_60'
  
  -- Timestamps
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_quotes_tenant  ON quotes(tenant_id);
CREATE INDEX IF NOT EXISTS idx_quotes_owner   ON quotes(owner_id);
CREATE INDEX IF NOT EXISTS idx_quotes_status  ON quotes(tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_quotes_updated ON quotes(tenant_id, updated_at DESC);

-- ── 5. SIGNING PAGES (bestaande tabel, nu met tenant_id) ────────────────────
-- Als je al een signing_pages tabel hebt, voeg tenant_id toe:
-- ALTER TABLE signing_pages ADD COLUMN IF NOT EXISTS tenant_id uuid REFERENCES tenants(id);

CREATE TABLE IF NOT EXISTS signing_pages (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id      uuid REFERENCES quotes(id) ON DELETE CASCADE,
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  html_content  text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz DEFAULT (now() + interval '90 days')
);

CREATE INDEX IF NOT EXISTS idx_signing_tenant ON signing_pages(tenant_id);

-- ── 6. PRODUCT LIBRARY (per tenant, herbruikbaar over offertes) ─────────────
CREATE TABLE IF NOT EXISTS products (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,
  reference   text,
  description text,
  category    text,
  unit_price  numeric,
  photos      text[],                                      -- URLs in Supabase Storage
  specs       jsonb,
  is_active   boolean DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_products_tenant ON products(tenant_id);

-- ── 7. PHOTO LIBRARY (per tenant) ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS photo_library (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  filename    text NOT NULL,
  url         text NOT NULL,
  tags        text[],
  uploaded_by uuid REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_photos_tenant ON photo_library(tenant_id);

-- ── 8. INVITATIONS ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invitations (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  role        text DEFAULT 'user',
  invited_by  uuid REFERENCES users(id),
  accepted_at timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now(),
  expires_at  timestamptz DEFAULT (now() + interval '7 days')
);


-- ═══════════════════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS) — de kern van tenant-isolatie
-- ═══════════════════════════════════════════════════════════════════════════

-- Helper functie: haal tenant_id op van de ingelogde gebruiker
CREATE OR REPLACE FUNCTION get_my_tenant_id()
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER
AS $$
  SELECT tenant_id FROM users WHERE id = auth.uid();
$$;

-- ── TENANTS: alleen eigen tenant zien ───────────────────────────────────────
ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenants_select ON tenants FOR SELECT
  USING (id = get_my_tenant_id());

-- ── TENANT SETTINGS ────────────────────────────────────────────────────────
ALTER TABLE tenant_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY ts_select ON tenant_settings FOR SELECT
  USING (tenant_id = get_my_tenant_id());
CREATE POLICY ts_update ON tenant_settings FOR UPDATE
  USING (tenant_id = get_my_tenant_id())
  WITH CHECK (tenant_id = get_my_tenant_id());

-- ── USERS ──────────────────────────────────────────────────────────────────
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY users_select ON users FOR SELECT
  USING (tenant_id = get_my_tenant_id());
CREATE POLICY users_update ON users FOR UPDATE
  USING (tenant_id = get_my_tenant_id());

-- ── QUOTES ─────────────────────────────────────────────────────────────────
ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;
CREATE POLICY quotes_select ON quotes FOR SELECT
  USING (tenant_id = get_my_tenant_id());
CREATE POLICY quotes_insert ON quotes FOR INSERT
  WITH CHECK (tenant_id = get_my_tenant_id());
CREATE POLICY quotes_update ON quotes FOR UPDATE
  USING (tenant_id = get_my_tenant_id());
CREATE POLICY quotes_delete ON quotes FOR DELETE
  USING (tenant_id = get_my_tenant_id());

-- ── SIGNING PAGES: publiek leesbaar (klanten zonder login), tenant-schrijven ─
ALTER TABLE signing_pages ENABLE ROW LEVEL SECURITY;
CREATE POLICY sp_public_read ON signing_pages FOR SELECT
  USING (true);  -- klanten moeten de ondertekenpagina kunnen zien zonder login
CREATE POLICY sp_tenant_write ON signing_pages FOR INSERT
  WITH CHECK (tenant_id = get_my_tenant_id());

-- ── PRODUCTS ───────────────────────────────────────────────────────────────
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
CREATE POLICY products_all ON products FOR ALL
  USING (tenant_id = get_my_tenant_id())
  WITH CHECK (tenant_id = get_my_tenant_id());

-- ── PHOTOS ─────────────────────────────────────────────────────────────────
ALTER TABLE photo_library ENABLE ROW LEVEL SECURITY;
CREATE POLICY photos_all ON photo_library FOR ALL
  USING (tenant_id = get_my_tenant_id())
  WITH CHECK (tenant_id = get_my_tenant_id());

-- ── INVITATIONS ────────────────────────────────────────────────────────────
ALTER TABLE invitations ENABLE ROW LEVEL SECURITY;
CREATE POLICY invitations_select ON invitations FOR SELECT
  USING (tenant_id = get_my_tenant_id() OR email = auth.email());
CREATE POLICY invitations_insert ON invitations FOR INSERT
  WITH CHECK (tenant_id = get_my_tenant_id());


-- ═══════════════════════════════════════════════════════════════════════════
-- SEED: Ricoh als eerste tenant (backward compatible)
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO tenants (id, name, slug, plan) VALUES
  ('00000000-0000-0000-0000-000000000001', 'RICOH Belgium NV', 'ricoh', 'enterprise')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO tenant_settings (
  tenant_id, company_name, company_name_short, app_name,
  primary_color, accent_color,
  logo_url, address, phone, fax, website,
  vat_number, rsz_number, vat_label, rsz_label,
  zone_label, zone_label_plural, zone_tab_label,
  leasing_enabled, leasing_label, leasing_label_full,
  default_language, default_vat_pct,
  conditions, client_responsibilities,
  maintenance_text, maintenance_items, proposal_items,
  signing_legal_url,
  ai_role, ai_sector,
  login_email_placeholder, session_file_extension, storage_prefix
) VALUES (
  '00000000-0000-0000-0000-000000000001',
  'RICOH Belgium NV', 'RICOH Belgium', 'Easy Quotation',
  '#BE1622', '#9b1019',
  NULL, -- logo_url: null = gebruik ingebouwde SVG
  'Medialaan 28A, 1800 Vilvoorde', '02/558.26.00', '02/558.27.15', 'ricoh.be',
  'BE 0418.856.193', '010 -160 1843- 44',
  'Ondernemingsnummer bij de BTW', 'Inschrijvingsnummer bij de RSZ',
  'Vergaderzaal', 'Vergaderzalen', 'Zalen',
  true, 'MRaaS', 'Meeting Room as a Service',
  'nl', 21,
  ARRAY[
    'De ruimte moet schoon en bruikbaar zijn voor aanvang der werken.',
    'Het openen/sluiten van verlaagde wanden of plafonds valt niet onder de verantwoordelijkheid van Ricoh.',
    'Ricoh voldoet aan HDCP-voorschriften (High Bandwidth Digital Content Protection).'
  ],
  ARRAY[
    'Snij-, breek- en freeswerk en bouwkundige uithollingen.',
    'Verstevigingen voor montage van luidsprekers, flatscreens of projectoren.',
    'Installatie van bekabeling, LAN-aansluitpunten en 230V aansluitpunten.',
    'Alle kosten verbonden aan parkeren en wachttijd.'
  ],
  'Het onderhoudscontract omvat volledige ontzorging van de geïnstalleerde AV-oplossing vanaf de installatiedatum.',
  ARRAY[
    'Helpdesk via online portaal — automatische tickettoewijzing',
    'Gedetailleerd field rapport na elke interventie',
    'Hersteltijd: next business day',
    'Eerste evaluatie na 1 maand gebruik'
  ],
  ARRAY['Projectmanagement', 'Levering en terugname verpakkingen', 'Installatie & testen'],
  'https://www.ricoh.be/nl/company/legal',
  'Je bent AV & meeting room specialist bij {companyNameShort}.',
  'AV',
  'naam@ricoh.be', '.ricoh', 'ricoh_'
)
ON CONFLICT (tenant_id) DO NOTHING;


-- ═══════════════════════════════════════════════════════════════════════════
-- SUPABASE STORAGE: buckets per tenant
-- ═══════════════════════════════════════════════════════════════════════════
-- Maak een "tenant-assets" bucket aan in Supabase Dashboard > Storage
-- Bestandsstructuur: tenant-assets/{tenant_id}/logos/...
--                    tenant-assets/{tenant_id}/photos/...
--                    tenant-assets/{tenant_id}/covers/...


-- ═══════════════════════════════════════════════════════════════════════════
-- AUTO-UPDATE timestamps
-- ═══════════════════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tr_tenants_updated BEFORE UPDATE ON tenants
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER tr_ts_updated BEFORE UPDATE ON tenant_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER tr_quotes_updated BEFORE UPDATE ON quotes
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER tr_products_updated BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
