// Ricoh Offerte Studio Pro - Service Worker v8
// Timestamp: 2026-06-22T00:00:00Z
var CACHE = "ricoh-offerte-v8";
var INDEX = "index.html";

self.addEventListener("install", function(e) {
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE).then(function(cache) {
      return Promise.all([
        "index.html",
        "manifest.json",
        "icon192.png",
        "icon512.png",
        "appletouchicon.png"
      ].map(function(url) {
        return cache.add(url).catch(function(err) {
          console.log("SW cache skip:", url, err);
        });
      }));
    })
  );
});

self.addEventListener("activate", function(e) {
  e.waitUntil(
    // Verwijder ALLE oude caches, niet alleen de vorige versie
    caches.keys().then(function(keys) {
      return Promise.all(
        keys.filter(function(k) { return k !== CACHE; })
            .map(function(k) {
              console.log("SW: verwijder oude cache:", k);
              return caches.delete(k);
            })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener("fetch", function(e) {
  var req = e.request;
  var url = req.url;

  // Externe diensten: nooit via SW
  if(url.includes("supabase.co") ||
     url.includes("api.anthropic.com") ||
     url.includes("workers.dev") ||
     url.includes("googleapis.com")) {
    return;
  }

  // Navigatie naar een echt bestaand bestand (bv. sign.html) NIET omleiden naar index.html.
  // Alleen "kale" app-navigatie (root of index.html) krijgt de SPA-fallback.
  if(req.mode === "navigate") {
    var isAppRoot = url.endsWith("/") || url.indexOf("index.html") !== -1;
    var hasOwnPage = /\/[a-z0-9_-]+\.html(\?|$|#)/i.test(url) && url.indexOf("index.html") === -1;
    if(hasOwnPage || !isAppRoot) {
      // Laat sign.html en andere echte pagina's gewoon van het netwerk komen
      e.respondWith(
        fetch(req).then(function(r){
          if(r && r.status === 200){ var cl=r.clone(); caches.open(CACHE).then(function(c){c.put(req,cl);}); }
          return r;
        }).catch(function(){ return caches.match(req); })
      );
      return;
    }
    // Kale app-navigatie: verse index.html
    e.respondWith(
      fetch(INDEX, {cache: "no-cache"}).then(function(r) {
        if(r && r.status === 200) {
          var clone = r.clone();
          caches.open(CACHE).then(function(c) { c.put(INDEX, clone); });
        }
        return r;
      }).catch(function() {
        return caches.match(INDEX);
      })
    );
    return;
  }

  // Overige assets: network-first
  e.respondWith(
    fetch(req).then(function(r) {
      if(r && r.status === 200) {
        var clone = r.clone();
        caches.open(CACHE).then(function(c) { c.put(req, clone); });
      }
      return r;
    }).catch(function() {
      return caches.match(req);
    })
  );
});
