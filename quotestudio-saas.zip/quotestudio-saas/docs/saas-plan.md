# QuoteStudio SaaS — Transformatieplan

## Van Ricoh-tool naar multi-tenant platform

---

## 1. Wat je al hebt (en wat het waard is)

De huidige Ricoh Offerte Studio is verrassend feature-complete:

| Functie | Status | SaaS-waarde |
|---|---|---|
| Import via screenshot/PDF/Excel + AI-extractie | ✅ Werkt | Hoog — dit is je killer feature |
| Zone-gebaseerd itemmanagement ("Zalen") | ✅ Werkt | Hoog — universeel inzetbaar |
| AI-gegenereerde productbeschrijvingen | ✅ Werkt | Hoog |
| Fotobibliotheek + auto-koppeling | ✅ Werkt | Medium |
| Professionele PDF-offerte met cover | ✅ Werkt | Hoog |
| MRaaS / huurformules | ✅ Werkt | Hoog — "as-a-Service" is trending |
| Digitale ondertekening via Supabase | ✅ Werkt | Hoog |
| Cloud opslag + dashboard | ✅ Werkt | Medium |
| Gebruikersbeheer / uitnodigingen | ✅ Werkt | Hoog |
| Meertalig (NL/FR/EN) | ✅ Werkt | Hoog voor Belgische markt |
| PWA + offline-capable | ✅ Werkt | Medium |
| 360°-foto's (Pannellum) | ✅ Werkt | Niche maar uniek |

**Conclusie:** je bouwt niet from scratch — je refactort en veralgemeent.

---

## 2. Architectuur: huidig vs. doel

### Huidig (monoliet)
```
┌─────────────────────────────────────┐
│  index.html (~12.000 regels)        │
│  ┌───────────────────────────────┐  │
│  │ Hardcoded Ricoh branding      │  │
│  │ Hardcoded voorwaarden/teksten │  │
│  │ Hardcoded logo SVG            │  │
│  │ Hardcoded BTW/RSZ-nummers     │  │
│  │ localStorage per gebruiker    │  │
│  └───────────────────────────────┘  │
│  Supabase: signing_pages tabel      │
│  Worker: AI-proxy (Claude API)      │
└─────────────────────────────────────┘
```

### Doel (multi-tenant SaaS)
```
┌─ Frontend (SPA of lichte framework) ─────────────────┐
│                                                       │
│  quotestudio.app                                      │
│  ├── /login          → Auth (Supabase Auth)           │
│  ├── /onboarding     → Branding wizard                │
│  ├── /app            → Offerte-editor (jouw tool)     │
│  ├── /dashboard      → Offertes + analytics           │
│  ├── /settings       → Tenant config                  │
│  └── /sign/:id       → Klant-ondertekenpagina         │
│                                                       │
└───────────────────────────────────────────────────────┘
          │
          ▼
┌─ Supabase (backend) ─────────────────────────────────┐
│                                                       │
│  Auth          → Email/password + magic link          │
│  Database      → Zie schema hieronder                 │
│  Storage       → Logo's, productfoto's, covers        │
│  Edge Functions→ AI-proxy, PDF-gen, webhooks          │
│  RLS           → Tenant-isolatie op rijniveau          │
│                                                       │
└───────────────────────────────────────────────────────┘
```

---

## 3. Database-schema (Supabase / PostgreSQL)

```sql
-- Kern: organisaties en gebruikers
tenants (
  id uuid PK,
  name text,                    -- "Electroworks BV"
  slug text UNIQUE,             -- "electroworks" → electroworks.quotestudio.app
  plan text DEFAULT 'free',     -- free | pro | enterprise
  created_at timestamptz
)

tenant_settings (
  tenant_id uuid FK → tenants,
  -- Branding
  logo_url text,
  primary_color text,           -- "#BE1622" → configureerbaar
  accent_color text,
  cover_image_url text,
  -- Bedrijfsgegevens
  company_name text,
  address text,
  vat_number text,
  phone text,
  email text,
  website text,
  -- Offerte-instellingen
  zone_label text DEFAULT 'Zone',  -- "Vergaderzaal", "Verdieping", "Gebouw"
  currency text DEFAULT 'EUR',
  default_vat_pct numeric DEFAULT 21,
  default_language text DEFAULT 'nl',
  -- Voorwaarden (rich text)
  terms_conditions text[],
  client_responsibilities text[],
  maintenance_terms text[],
  -- Huur/leasing
  leasing_enabled boolean DEFAULT false,
  leasing_label text DEFAULT 'As-a-Service',
  leasing_terms jsonb,           -- {36: {pct: 5, warranty: 200}, 48: {...}}
  -- Ondertekenpagina
  signing_legal_text text,
  signing_legal_url text
)

users (
  id uuid PK,                   -- = Supabase Auth uid
  tenant_id uuid FK → tenants,
  email text,
  name text,
  role text DEFAULT 'user',     -- admin | user | viewer
  last_active timestamptz
)

-- Productcatalogus (per tenant)
products (
  id uuid PK,
  tenant_id uuid FK,
  name text,
  reference text,
  description text,
  category text,
  unit_price numeric,
  photos text[],                -- URLs in Supabase Storage
  specs jsonb,
  created_at timestamptz
)

-- Offertes
quotes (
  id uuid PK,
  tenant_id uuid FK,
  owner_id uuid FK → users,
  client_name text,
  client_email text,
  client_address text,
  client_vat text,
  client_contact text,
  project_name text,
  status text DEFAULT 'draft',  -- draft | sent | signed | won | lost
  cover_title text,
  cover_image_url text,
  discount_pct numeric DEFAULT 0,
  discount_label text,
  language text DEFAULT 'nl',
  valid_until date,
  signed_at timestamptz,
  signature_data text,
  version int DEFAULT 1,
  created_at timestamptz,
  updated_at timestamptz
)

zones (
  id uuid PK,
  quote_id uuid FK → quotes,
  name text,                    -- "Vergaderzaal A", "Verdieping 2", etc.
  description text,
  photo_url text,
  sort_order int
)

zone_items (
  id uuid PK,
  zone_id uuid FK → zones,
  product_id uuid FK → products NULL,  -- optioneel: link naar catalogus
  name text,
  reference text,
  description text,
  qty int DEFAULT 1,
  unit_price numeric,
  photo_url text,
  optional boolean DEFAULT false,
  sort_order int
)

-- Ondertekenpagina's
signing_pages (
  id uuid PK,
  quote_id uuid FK → quotes,
  tenant_id uuid FK,
  html_content text,
  created_at timestamptz,
  expires_at timestamptz
)

-- Fotobibliotheek
photo_library (
  id uuid PK,
  tenant_id uuid FK,
  filename text,
  url text,
  tags text[],
  uploaded_by uuid FK → users,
  created_at timestamptz
)
```

**Row Level Security (RLS):** elke tabel krijgt een policy:
```sql
CREATE POLICY tenant_isolation ON quotes
  USING (tenant_id = (SELECT tenant_id FROM users WHERE id = auth.uid()));
```

---

## 4. Wat moet er veranderen in de code

### 4a. Ontvlechten (fase 1 — meeste werk)

| Hardcoded element | Waar nu | Wordt |
|---|---|---|
| `#BE1622` (Ricoh rood) | CSS `:root`, 50+ plekken | `tenant_settings.primary_color` → CSS var |
| `RICOH_LOGO_SVG` | JS variabele (~180 regels SVG) | `tenant_settings.logo_url` → `<img>` |
| BTW `BE 0418.856.193` | In PDF-generatie | `tenant_settings.vat_number` |
| RSZ `010-160 1843-44` | In PDF-generatie | Veld in tenant_settings |
| Voorwaarden-teksten | `cond_items[]`, `client_list[]` etc. | `tenant_settings` arrays |
| "Vergaderzalen" label | Overal in UI + PDF | `tenant_settings.zone_label` |
| MRaaS-teksten | Hardcoded | `tenant_settings.leasing_*` |
| `ricoh.be/nl/company/legal` | Ondertekenpagina | `tenant_settings.signing_legal_url` |
| Worker URL + token | localStorage | Per-tenant config of shared Edge Function |
| Supabase credentials | Hardcoded | Env vars (zelfde project, RLS doet isolatie) |

### 4b. Toevoegen (fase 2)

- **Auth flow:** login/registratie → Supabase Auth
- **Onboarding wizard:** logo uploaden, kleuren kiezen, bedrijfsinfo, zone-label
- **Tenant admin:** gebruikers beheren, branding aanpassen, voorwaarden bewerken
- **Productcatalogus:** herbruikbare items per organisatie (nu is alles per-offerte)
- **Subdomain/slug routing:** `electroworks.quotestudio.app`

### 4c. Behouden (gewoon werkt)

- De volledige offerte-editor (core van de app)
- AI-import via screenshot/PDF/Excel
- AI-beschrijvingen genereren
- PDF-preview en -export
- Ondertekenpagina-flow
- Dashboard + statistieken
- Meertaligheid (i18n-systeem is al aanwezig)

---

## 5. Fasering

### Fase 0 — Voorbereiding (1-2 weken)
- [ ] Kies een naam en domein (bv. `quotestudio.app`, `offertepro.be`)
- [ ] Supabase-project opzetten met nieuw schema + RLS
- [ ] Bestaande index.html opsplitsen in modules (of naar een licht framework)
- [ ] Alle hardcoded Ricoh-referenties inventariseren (grep op "ricoh", "RICOH", "#BE1622", "Belgium NV", BTW-nummers, etc.)

### Fase 1 — Multi-tenant kern (3-4 weken)
- [ ] Auth: login, registratie, magic link
- [ ] Tenant-aanmaak + onboarding wizard
- [ ] Branding-engine: kleuren, logo, zone-label dynamisch laden
- [ ] Voorwaarden + bedrijfsinfo uit tenant_settings i.p.v. hardcoded
- [ ] PDF-generatie dynamisch maken (logo, kleuren, teksten uit config)
- [ ] Signing page dynamisch (tenant branding)

### Fase 2 — Productcatalogus + opslag (2-3 weken)
- [ ] Productcatalogus per tenant (CRUD)
- [ ] Foto's naar Supabase Storage (i.p.v. base64 in localStorage)
- [ ] Auto-suggest bij item toevoegen uit eigen catalogus
- [ ] Import verrijkt catalogus automatisch

### Fase 3 — Team & samenwerking (2 weken)
- [ ] Gebruikers uitnodigen (al deels gebouwd)
- [ ] Rollen: admin / editor / viewer
- [ ] Offerte-eigenaarschap + delen
- [ ] Activiteitenlog

### Fase 4 — Monetisatie & groei (doorlopend)
- [ ] Stripe-integratie voor abonnementen
- [ ] Planlimieten (free: 5 offertes/maand, pro: onbeperkt)
- [ ] Custom domain per tenant (enterprise)
- [ ] Template-marktplaats (sectorspecifieke startpakketten)
- [ ] API voor integraties (CRM, boekhoudpakketten)

---

## 6. Pricing-model (suggestie)

| Plan | Prijs | Inclusief |
|---|---|---|
| **Free** | €0 | 1 gebruiker, 5 offertes/maand, watermerk |
| **Pro** | €29/maand | 5 gebruikers, onbeperkt, eigen branding, digitale handtekening |
| **Business** | €79/maand | 15 gebruikers, productcatalogus, dashboard analytics, priority support |
| **Enterprise** | Op maat | Custom domain, SSO, API, SLA, dedicated onboarding |

---

## 7. Tech-stack keuze

### Optie A: Incrementeel (aanbevolen om snel te starten)
Behoud de huidige vanilla JS-aanpak, maar splits `index.html` op in bestanden en laad tenant-config bij opstart vanuit Supabase. Voordeel: je kent de codebase, minimaal risico.

### Optie B: Modern framework
Migreer naar Next.js of Nuxt met Supabase als backend. Voordeel: SSR voor SEO (landingspagina), betere code-organisatie, makkelijker onderhoud op lange termijn. Nadeel: volledige herschrijving van de UI.

### Aanbeveling
Start met **Optie A** voor de eerste betalende klanten, plan **Optie B** als de traction er is. De huidige ~12.000-regels monoliet is groot maar werkt — en herschrijven vóór je klanten hebt is premature optimization.

---

## 8. Eerste concrete stap

Maak een `tenantConfig`-object dat bij opstart geladen wordt en alle hardcoded waarden vervangt:

```javascript
// Wordt geladen vanuit Supabase bij app-start
var tenantConfig = {
  name: "Ricoh Belgium",           // ← was hardcoded
  logo: "https://..../logo.svg",   // ← was RICOH_LOGO_SVG
  primaryColor: "#BE1622",         // ← was --red in :root
  accentColor: "#9b1019",          // ← was --rd
  vatNumber: "BE 0418.856.193",    // ← was inline string
  zoneLabel: "Vergaderzaal",       // ← was hardcoded "Zalen"
  leasingLabel: "MRaaS",           // ← was hardcoded
  terms: [...],                    // ← was cond_items[]
  clientResp: [...],               // ← was client_list[]
  signingLegalUrl: "https://...",  // ← was ricoh.be link
  // ...
};

// Dan overal: tenantConfig.primaryColor i.p.v. "#BE1622"
```

Dit is de kleinste verandering met de grootste impact — zodra dit werkt, is de app al "white-label ready" en kun je de eerste niet-Ricoh-klant onboarden.
