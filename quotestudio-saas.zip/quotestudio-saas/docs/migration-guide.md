# Migratie-gids: index.html → multi-tenant

## Stap 0: Voeg tenant-config.js toe
Voeg `<script src="tenant-config.js"></script>` toe vóór de bestaande `<script>`-blokken.

---

## Stap 1: CSS-variabelen (automatisch via TC.applyTheme)

De `--red`, `--rd`, `--rl` variabelen in `:root` blijven als defaults bestaan.
`TC.applyTheme()` overschrijft ze bij opstart. **Geen handmatige wijziging nodig.**

Wel verwijderen:
```
// Regel 26: hardcoded theme-color → wordt dynamisch via TC.applyTheme()
<meta name="theme-color" content="#BE1622">
→ <meta name="theme-color" content="#2563eb">  (neutrale default, TC overschrijft)
```

---

## Stap 2: Inline hardcoded kleuren (#BE1622)

Er zijn ~50 plekken waar `#BE1622` inline in HTML/JS staat (niet via CSS var).
Deze moeten `TC.get("primaryColor")` worden of `var(--red)` gebruiken.

### Patroon A: inline style in statische HTML
```html
<!-- VOOR -->
style="background:#BE1622;color:#fff"

<!-- NA (optie 1: CSS var) -->
style="background:var(--red);color:#fff"

<!-- NA (optie 2: als het in JS-gegenereerde HTML zit) -->
style="background:'+TC.get("primaryColor")+';color:#fff"
```

### Belangrijkste locaties:
- Regel 1002: `.lp-left` gradient → gebruik CSS vars
- Regel 1006: `.lp-logo-sq span` kleur → `var(--red)`
- Regel 1027: `.lp-btn` achtergrond → `var(--red)`
- Regel 1359, 1442, 1450: AI-chat buttons gradient
- Regel 1935: dashboard KPI kleur
- Regel 2075: opslaan-button
- Regel 2320-2367: gebruikersbeheer modal
- Regel 2632-2678: zone-viewer CSS (dynamisch aangemaakt)

### rgba() met hardcoded waarden:
```
rgba(190,22,34,.09)   →  TC heeft primaryRgb, maar eenvoudiger:
                         gebruik CSS: color-mix(in srgb, var(--red) 9%, transparent)
                         of bereken met TC.get("primaryRgb")
```

---

## Stap 3: RICOH_LOGO_SVG → TC.logo() / TC.logoPdf()

### Regel 5929: definitie
```javascript
// VOOR
var RICOH_LOGO_SVG='<svg viewBox="0 0 141 62"...></svg>';

// NA — bewaar als fallback, maar gebruik TC
var RICOH_LOGO_SVG = TC.getRaw("logoSvgInline") || '<svg viewBox="0 0 141 62"...></svg>';
// Stel in als fallback voor Ricoh-tenant:
if (!TC.getRaw("logoUrl") && !TC.getRaw("logoSvgInline")) {
  TC.set("logoSvgInline", RICOH_LOGO_SVG);
}
```

### Overal waar RICOH_LOGO_SVG in HTML wordt geïnjecteerd:
```javascript
// VOOR
+'<div class="cvr-rl">'+RICOH_LOGO_SVG+'</div>'

// NA
+'<div class="cvr-rl">'+TC.logoPdf()+'</div>'
```

---

## Stap 4: Bedrijfsnaam & -gegevens

### Regel 9843: Cover-pagina
```javascript
// VOOR
'RICOH Belgium NV</strong><br>voor<br>'

// NA
TC.get("companyName")+'</strong><br>voor<br>'
```

### Regel 9633: PDF footer
```javascript
// VOOR
var ft="RICOH Belgium NV \u2014 Medialaan 28A, 1800 Vilvoorde \u2014 02/558.26.00";

// NA
var ft = TC.pdfFooter();
```

### Regel 9914-9915: BTW/RSZ
```javascript
// VOOR
'Inschrijvingsnummer bij de RSZ</strong>&nbsp; <strong>010 -160 1843- 44</strong>'
'Ondernemingsnummer bij de BTW</strong>&nbsp; <strong>BE 0418.856.193</strong>'

// NA
TC.get("rszLabel")+'&nbsp; <strong>'+TC.get("rszNumber")+'</strong>'
TC.get("vatLabel")+'&nbsp; <strong>'+TC.get("vatNumber")+'</strong>'
```

---

## Stap 5: Ondertekenpagina (regel ~8898-8945)

```javascript
// VOOR
+'algemene voorwaarden van RICOH Belgium NV</strong> (<a href="https://www.ricoh.be/nl/company/legal"...'

// NA
+TC.get("signingLegalText")+'</strong>'
+(TC.get("signingLegalUrl") ? ' (<a href="'+TC.get("signingLegalUrl")+'"...>' : '')

// VOOR  
+'Ik aanvaard de algemene voorwaarden</strong> van RICOH Belgium NV</span></label>'

// NA
+TC.get("signingCheckbox")+'</span></label>'

// VOOR
+'RICOH Belgium NV \u2014 Medialaan 28A, 1800 Vilvoorde \u2014 <a href="https://www.ricoh.be"...'

// NA
+TC.get("signingFooter")
```

---

## Stap 6: Login-pagina (regel ~1052-1097, ~11390-11392)

```javascript
// VOOR
<div class="lp-brand">RICOH Belgium</div>
<input ... placeholder="naam@ricoh.be" ...>
<div class="lp-foot">© RICOH Belgium NV · Uitnodiging vereist...</div>

// NA — dynamisch bij opstart (of via TC in de i18n-strings)
document.querySelector(".lp-brand").textContent = TC.get("companyNameShort");
document.getElementById("lp-email").placeholder = TC.get("loginEmailPlaceholder");
document.getElementById("lp-t-foot").innerHTML = TC.get("loginFooter");
```

---

## Stap 7: i18n-strings met "Ricoh"

### contact_subtitle (NL/FR/EN elk)
```javascript
// VOOR
contact_subtitle: "Uw aanspreekpunten bij Ricoh Belgium",

// NA  
contact_subtitle: TC.get("contactSubtitle"),
// TC returnt "Uw aanspreekpunten bij {companyNameShort}" 
// → geïnterpoleerd tot "Uw aanspreekpunten bij RICOH Belgium" (of andere tenant)
```

### Dashboard owner-label
```javascript
// VOOR
"Ricoh medewerker"  /  "Collaborateur Ricoh"  /  "Ricoh employee"

// NA
TC.get("dashboardOwnerLabel")  // met taal-switch
```

---

## Stap 8: AI-prompts (regel ~4074, 4136, 4167-4170, 7145-7146)

```javascript
// VOOR
getSys("You are a professional translator and AV specialist at Ricoh Belgium...")
"Je bent AV & meeting room specialist bij Ricoh Belgium."

// NA
getSys(TC.get("aiTranslateRole"))
TC.get("aiRole")  // geïnterpoleerd met tenant-naam
```

---

## Stap 9: Voorwaarden (cond_items, client_list, maint_items)

```javascript
// VOOR (regel ~3118-3132)
cond_items: [
  "De ruimte moet schoon en bruikbaar zijn...",
  "Het openen/sluiten... niet onder de verantwoordelijkheid van Ricoh.",
  ...
],

// NA
cond_items: TC.getRaw("conditions") || [...defaults...],
```

---

## Stap 10: localStorage-keys (regel ~6200)

```javascript
// VOOR
var STOR="ricoh_v3", LIB_KEY="ricoh_lib_v1", FOTOBIB_KEY="ricoh_fotos_v1"...

// NA
var STOR      = TC.storageKey("v3"),
    LIB_KEY   = TC.storageKey("lib_v1"),
    FOTOBIB_KEY = TC.storageKey("fotos_v1"),
    ITEMS_KEY = TC.storageKey("items_v1"),
    ZAALTPL_KEY = TC.storageKey("zaaltpl_v1");
```

---

## Stap 11: Bestandsformaat (.ricoh → dynamisch)

```javascript
// VOOR
accept=".ricoh,.json"
x.download = name + ".ricoh";

// NA
accept = TC.fileExt() + ",.json"
x.download = name + TC.fileExt();
```

---

## Stap 12: Zone-terminologie ("Vergaderzaal" → dynamisch)

### In de i18n-objecten:
```javascript
// VOOR
"Vergaderzalen": "Salles de réunion",
"Nog geen zalen.": "Aucune salle.",

// NA — gebruik TC.get("zoneLabelPlural") dynamisch
// Of vervang in de i18n met template-variabelen
```

### In de UI:
```javascript
// VOOR
"Maak vergaderzalen aan op tabblad \u201eZalen\u201d"

// NA
"Maak " + TC.get("zoneLabelPlural").toLowerCase() + " aan op tabblad \u201e" + TC.get("zoneTabLabel") + "\u201d"
```

---

## Stap 13: App-opstart sequentie

```javascript
// Nieuwe opstart-flow (bovenaan de <script>)

// 1. Supabase client initialiseren (bestaande code)
var _supaClient = supabase.createClient(SUPA_URL, SUPA_ANON);

// 2. Na login: tenant-config laden
async function initTenant(userId) {
  // Haal user op om tenant_id te kennen
  var { data: user } = await _supaClient
    .from("users")
    .select("tenant_id")
    .eq("id", userId)
    .single();

  if (user && user.tenant_id) {
    await TC.loadFromSupabase(_supaClient, user.tenant_id);
  }
  
  // 3. Theme toepassen
  TC.applyTheme();
  
  // 4. Bestaande init-code uitvoeren
  initApp();
}
```

---

## Samenvatting: 13 categorieën, ~207 referenties

| Categorie | Aantal | Aanpak |
|-----------|--------|--------|
| CSS kleur `#BE1622` | ~50 | → `var(--red)` + TC.applyTheme() |
| `RICOH_LOGO_SVG` | ~8 | → `TC.logo()` / `TC.logoPdf()` |
| Bedrijfsnaam/-gegevens | ~25 | → `TC.get("companyName")` etc. |
| Ondertekenpagina | ~5 | → `TC.get("signing*")` |
| Login-pagina | ~8 | → `TC.get("login*")` |
| i18n "Ricoh" strings | ~20 | → TC-geïnterpoleerde strings |
| AI-prompts | ~8 | → `TC.get("aiRole")` etc. |
| Voorwaarden-teksten | ~15 | → `TC.getRaw("conditions")` etc. |
| localStorage keys | ~12 | → `TC.storageKey()` |
| .ricoh bestandsformaat | ~8 | → `TC.fileExt()` |
| Zone-terminologie | ~30 | → `TC.get("zoneLabel*")` |
| PDF footer/cover | ~8 | → `TC.pdfFooter()`, `TC.get()` |
| Meta/manifest | ~10 | → dynamisch bij opstart |
